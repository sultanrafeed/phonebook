package DEM;

public class main {
  
	public static void main(String[] args ) {
  LoginFrame frame = new LoginFrame();
}
}